﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace AdultLink
{
	public class Index : MonoBehaviour {

		public int index;
	}
	
}
